export const barData = [
  {
    date: "2025-08-08",
    point: 1,
    emotion: "happy",
    text: "오늘은 기분이 꽤 괜찮았어 :)",
  },
  {
    date: "2025-08-09",
    point: 4,
    emotion: "tired",
    text: "몸이 무겁고 쉽게 지치는 하루였어.",
  },
  {
    date: "2025-08-10",
    point: 5,
    emotion: "disgust",
    // 일부러 생략
  },
  {
    date: "2025-08-11",
    point: 3,
    emotion: "happy",
    text: "소소하지만 좋은 일이 있었어!",
  },
  {
    date: "2025-08-12",
    point: 8,
    emotion: "sad",
    text: "괜히 울적하고 마음이 가라앉는 날이었어.",
  },
  {
    date: "2025-08-13",
  },
  {
    date: "2025-08-14",
    point: 9,
    emotion: "tired",
    // 일부러 생략
  },
];
