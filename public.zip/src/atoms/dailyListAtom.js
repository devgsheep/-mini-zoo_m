import { atom } from "recoil";

export const dailyListAtom = atom({
  key: "dailyListAtom",
  default: [],
});
