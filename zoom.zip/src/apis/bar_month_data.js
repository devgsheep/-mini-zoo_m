export const barMonthData = [
  { date: "2025-07-20", emotion: "기쁨" },
  { date: "2025-07-20", emotion: "기쁨" },
  { date: "2025-07-20", emotion: "지침" },
  { date: "2025-07-21", emotion: "평온" },
  { date: "2025-07-21", emotion: "기쁨" },
  { date: "2025-07-22", emotion: "지침" },
  { date: "2025-07-22", emotion: "평온" },
  { date: "2025-07-23", emotion: "기쁨" },
  { date: "2025-07-23", emotion: "기쁨" },
  { date: "2025-07-23", emotion: "평온" },
];
