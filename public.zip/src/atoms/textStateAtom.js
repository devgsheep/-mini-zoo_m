import { atom } from "recoil";

export const textStateAtom = atom({
  key: "textStateAtom",
  default: "",
});
