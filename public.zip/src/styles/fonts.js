export const fonts = {
  black: "Black",
  bold: "Bold",
  extraBold: "ExtraBold",
  extraLight: "ExtraLight",
  light: "Light",
  medium: "Medium",
  regular: "Regular",
  semiBold: "SemiBold",
  thin: "Thin",
};
