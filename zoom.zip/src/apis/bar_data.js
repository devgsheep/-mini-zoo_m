export const barData = [
  {
    date: "2025-07-16",
    point: 5,
    emotion: "happy",
  },
  {
    date: "2025-07-17",
    point: 3,
    emotion: "sad",
  },
  {
    date: "2025-07-18",
    point: 8,
    emotion: "angry",
  },
  {
    date: "2025-07-19",
    point: 2,
    emotion: "boring",
  },
  {
    date: "2025-07-20",
    point: 9,
    emotion: "anxious",
  },
  {
    date: "2025-07-21",
    point: 1,
    emotion: "disgust",
  },
  {
    date: "2025-07-22",
    point: 4,
    emotion: "embarrassed",
  },
];
